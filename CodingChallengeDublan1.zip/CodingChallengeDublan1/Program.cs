﻿using System;
using System.Runtime.ConstrainedExecution;

class Challenges
{
    public static void Main(string[] args)
    {

        Console.WriteLine("Welcome to my coding challenge program. There will be a variety of different functions you will have to choose from. Please pick one.");

        Console.WriteLine("Today we are going to usse the number adder called SUM. Please input two numbers for us to add. \n");

        var number1 = Console.ReadLine();
        int number1int = int.Parse(number1);

        Console.Write("Wow! Your stupid! Please Input one more number!");

        var number2 = Console.ReadLine();
        int number2int = int.Parse(number2);

        Console.WriteLine("The sum of the number: " + number1 + " and the number: number2 " + "is equal to: " + Sum(number1int, number2int));

        Console.WriteLine("Let's try converting minutes into seconds. Give me a number to convert minutes to seconds.");
        var number3 = Console.ReadLine();
        int number3int = int.Parse(number3);

        Console.WriteLine(number3 + " Minutes converted to seconds is: " + Convert(number3int) + " seconds " );

        Sum(number1int, number2int);

        Console.WriteLine("Now input any number and I will add 1 digit to it.");
        var appendicitis = Console.ReadLine();
        int appendicitisint = int.Parse(appendicitis);

        Console.WriteLine(appendicitis + " and add 1 digit and you get: " + AddOne(appendicitisint));

        Console.WriteLine("Let's try calculating circuit power! \n");

        Console.WriteLine("Give me a value for your voltage.");
        var stupidity = Console.ReadLine();
        int stupidityint = int.Parse(stupidity);

        Console.WriteLine("Give me the current value human.");
        var foolishness = Console.ReadLine();
        int foolishnessint = int.Parse(foolishness);

        Console.WriteLine("Your circuit power is equal to: " + VoltConvert(stupidityint, foolishnessint));
        VoltConvert(stupidityint, foolishnessint);





    }

    public static int Sum(int number1, int number2)
    { return number1 + number2; }

    public static int Convert(int number)
    {
        return number * 60;
    }

    public static int AddOne(int appendicitis)
    {
        return appendicitis += 1;
    }

    public static int VoltConvert(int stupidity, int foolishness)
    {
        return stupidity * foolishness;
    }
}


